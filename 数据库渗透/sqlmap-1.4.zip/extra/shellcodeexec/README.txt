Binary files in this folder are data files used by sqlmap on the target
system, but not executed on the system running sqlmap. They are licensed
under the terms of the GNU Lesser General Public License and their source
code is available on https://github.com/inquisb/shellcodeexec.
