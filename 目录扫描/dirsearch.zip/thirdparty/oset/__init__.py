"""Main Ordered Set module """

from .pyoset import oset
