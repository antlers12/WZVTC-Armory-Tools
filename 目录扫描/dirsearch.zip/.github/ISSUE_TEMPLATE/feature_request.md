---
name: Feature Request
about: Suggest a new feature for dirsearch improvement
labels: enhancement
---

### What is the feature?

What is it?

### What is the workflow?

How does it work?

### What is the use case?

When and who will use this?

#### Checker:

- [ ] This feature is in scope for the dirsearch purpose
